$(function () {
var ctx = document.getElementById("myChart").getContext('2d');
var myChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: ["المطاعم ", "العيادات الطبيه", "مراكز بصريات", " مشاغل نسائيه", "الكافهيات ", "الفود ترك", "الحلويات", "الملابس", "تنظيم حفلات وموتمرات", " سياحه وسفر", " دعايه واعلان", "كوش افراح",    "خدمات السيارات","معاهد "," مستحضرات تجميل","روضة اطفال"," اندية رياضية"],
        datasets: [{
            
            data: [4, 1, 20, 19, 33, 33, 44, 38, 20, 48, 33, 13,22,28,37,11,8],
            backgroundColor: [
              
              

                
            ],
           
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero:true
                }
            }]
        }
    }
});
   

});